//
//  Mathlic.h
//  Mathlic
//
//  Created by Selim KURNAZ on 12/02/2020.
//  Copyright © 2020 Selim KURNAZ. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for Mathlic.
FOUNDATION_EXPORT double MathlicVersionNumber;

//! Project version string for Mathlic.
FOUNDATION_EXPORT const unsigned char MathlicVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Mathlic/PublicHeader.h>


